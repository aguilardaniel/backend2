import { Router } from "express";

const viewsRouter = Router();

export default viewsRouter;
