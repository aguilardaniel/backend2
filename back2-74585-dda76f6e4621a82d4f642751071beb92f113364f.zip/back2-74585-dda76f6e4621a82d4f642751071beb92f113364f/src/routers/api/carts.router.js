import { Router } from "express";

const cartsRouter = Router();

export default cartsRouter;
